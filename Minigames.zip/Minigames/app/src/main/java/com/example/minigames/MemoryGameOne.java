package com.example.minigames;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

public class MemoryGameOne extends AppCompatActivity {
    Color[] colors={new Color(0xffff0000,"Red"),new Color(0xff0000ff,"Blue"),new Color(0xffffff00,"Yellow"),new Color(0xffffc0cb,"Pink"),new Color(0xffc0c0c0,"Silver"),new Color(0xfffa8072,"Salmon"),new Color(0xff008000,"Green"),new Color(0xff800080,"Purple"),new Color(0xffffffff,"White"),new Color(0xffffa500,"Orange"),new Color(0xff00008b,"DarkBlue"),new Color(0xffa52a2a,"Brown"),new Color(0xff87ceeb,"LightBlue"),new Color(0xff00ff00,"Lime"),new Color(0xffb22222,"Firebrick"),new Color(0xfff0f68c,"Khaki")};
    int[] buttons = {R.id.field00,R.id.field01,R.id.field02,R.id.field03, R.id.field10,R.id.field11,R.id.field12,R.id.field13, R.id.field20,R.id.field21,R.id.field22,R.id.field23, R.id.field30,R.id.field31,R.id.field32,R.id.field33};
    String[] checked = new String[16];
    List<Color> colorlist = Arrays.asList(colors);
    Color chosen=new Color();
    boolean start_clicked=false;
    int wrong,totalsteps,hits=0;
    Random rand= new Random();
    TextView stepscount,colorread;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_memory_game_one);
        //przemieszanie elementów tablicy kolorów
        Collections.shuffle(colorlist);
        colors = colorlist.toArray(new Color[16]);
        //"ujawnienie" wszystkich kolorów
        for(int i=0;i<16;i++){
            findViewById(buttons[i]).setBackgroundColor(colors[i].getCode());
            colors[i].setId(buttons[i]);
        }


    }
    @Override
    protected void onDestroy(){
        super.onDestroy();
        Toast.makeText(this,"Zamykam obecną rozgrywkę",Toast.LENGTH_LONG).show();
    }
    int i =0;
    //"ukrycie" kolorów
    public void start(View v){
        if(!start_clicked) {
            start_clicked = true;
            for (int i = 0; i < 16; i++) {
                findViewById(buttons[i]).setBackgroundColor(0x00000000);

            }
            //wybór pierwszego losowego koloru
            int r = rand.nextInt(16);
            colorread=(TextView)findViewById(R.id.colorsread);
            colorread.setText(colors[r].getName());
            chosen=colors[r];
        }
    }
    //funkcja po naciśnięciu przycisku sprawdza czy ten jego kolor zgadza się z obecnie wybranym kolorem
    //jesli tak to zapisuje nazwe koloru, który od tej pory bedzie ignorowac i zwieksza odpowiedna zmienną hits
    //w przeciwnym wypadku jednorazowo wyswietla pozycję tego koloru i gra toczy sie dalej
    public void reveal(View v){
        boolean repeat=true;
        if(start_clicked&&hits<16) {
            if(wrong!=0){
                findViewById(wrong).setBackgroundColor(0x00000000);
            }
            if (v.getId()==chosen.getId()&&!checkForColor(checked,chosen)) {
                findViewById(chosen.getId()).setBackgroundColor(chosen.getCode());
                checked[hits]=chosen.getName();
                wrong=0;
                hits++;
            }
            else{
                findViewById(chosen.getId()).setBackgroundColor(chosen.getCode());
                wrong=chosen.getId();
            }
            while(repeat&&hits<16) {
                int r = rand.nextInt(16);
                colorread = (TextView) findViewById(R.id.colorsread);
                colorread.setText(colors[r].getName());
                chosen = colors[r];
                if(checkForColor(checked,chosen)){
                    repeat=true;
                }
                else{
                    repeat=false;
                }
            }
            if(hits<=16) {
                totalsteps++;
                stepscount = (TextView) findViewById(R.id.nsteps);
                stepscount.setText(String.valueOf(totalsteps));
            }
        }
        else if (hits==16){
            Toast.makeText(this,"Jej udało ci się odsłonić wszystkie kolory w "+totalsteps+" ruchach!",Toast.LENGTH_LONG).show();
            colorread.setText("");
        }

    }
    //funkcja sprawdzająca czy wylosowany kolor jest unikatowy
    public boolean checkForColor(String[] checked,Color chosen){
        boolean ch = false;
        for (String a : checked){
            if(chosen.getName()==a){
                ch=true;
                break;
            }
            if(a==null){
                ch=false;
                break;
            }
        }
        return ch;
    }
    //Funkcja przycisku restart
    public void restartGame(View v){
        Intent i = getIntent();
        finish();
        startActivity(i);
    }
    //przejście do MainActivity
    public void showGameList(View v){
        Intent i = new Intent(this, MainActivity.class);
        finish();
        startActivity(i);
    }
}
class Color{
    private int code,id;
    private String name;

    public Color(int code,String name){
        this.code=code;
        this.name=name;
    }
    public Color(){

    }
    public int getCode(){
       return code;
    }
    public String getName(){
        return name;
    }
    public void setCode(int code){
        this.code=code;
    }
    public void setName(String name){
        this.name=name;
    }
    public void setId(int id){
        this.id=id;
    }
    public int getId(){
        return id;
    }
}
