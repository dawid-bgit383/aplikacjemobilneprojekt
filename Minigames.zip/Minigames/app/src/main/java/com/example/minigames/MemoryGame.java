package com.example.minigames;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class MemoryGame extends AppCompatActivity {
    String colors[]={"R","B","Y","P","P","R","G","PU","W","O","Y","W","B","G","O","PU"};
    List<String> colorlist = Arrays.asList(colors);
    int used=0;
    int totalpairs=0;
    int totalsteps=0;
    String revealed[]= new String[2];
    TextView stepscount;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_memory_game);
        String revealed[]={"",""};
        //przemieszanie elementów tablicy kolorów
        Collections.shuffle(colorlist);
        colors = colorlist.toArray(new String[16]);
    }
    @Override
    protected void onDestroy(){
        super.onDestroy();
        Toast.makeText(this,"Zamykam obecną rozgrywkę",Toast.LENGTH_LONG).show();
    }
    public void reveal(View v){
        //sprawdzanie ile przycisków jest odsłoniętych
        if(used==2){
            String temp[]=new String[2];
            String color1,color2,a,b;
            a =(String)findViewById(Integer.valueOf(revealed[0])).getTag();
            color1=colors[Integer.parseInt(a)];
            b =(String)findViewById(Integer.valueOf(revealed[1])).getTag();
            color2=colors[Integer.parseInt(b)];
            //porównanie kolorów pary oraz odpowiednio ponowne zasłonięcie, bądź większenie licznika dopasowanych par
            if(((color1!=color2)&&(totalpairs<8))||a==b){
                findViewById(Integer.valueOf(revealed[0])).setBackgroundColor(0x00000000);
                findViewById(Integer.valueOf(revealed[1])).setBackgroundColor(0x00000000);
            }
            else {
                totalpairs++;
            }
            if(totalpairs>=8){
                Toast.makeText(this,"Jej udało Ci się, twój wynik to: "+totalsteps+" kroków. Naciśnij przycisk RESTART aby zagrać jeszczę raz!",Toast.LENGTH_LONG).show();
            }
            //czyszczenie wybranych przycisków i ich ilości oraz zwiększenie i zaktualizowanie licznika kroków
            String revealed[]={"",""};
            used=0;
            if(totalpairs<8) {
                totalsteps++;
            }
            stepscount =(TextView)findViewById(R.id.nsteps);
            stepscount.setText(String.valueOf(totalsteps));
        }
       //"Odsłonięcie" odpowiednich przycisków, zapamiętanie tego przycisku oraz zwiększenie licznika używanych
        String temp =(String)findViewById(v.getId()).getTag();
        String color=colors[Integer.parseInt(temp)];
        switch(color){
            case "R":
                findViewById(v.getId()).setBackgroundColor(0xFFFF0000);
                break;
            case "G":
                findViewById(v.getId()).setBackgroundColor(0xFF008000);
                break;
            case "B":
                findViewById(v.getId()).setBackgroundColor(0xFF0000FF);
                break;
            case "W":
                findViewById(v.getId()).setBackgroundColor(0xFFFFFFFF);
                break;
            case "Y":
                findViewById(v.getId()).setBackgroundColor(0xFFFFFF00);
                break;
            case "P":
                findViewById(v.getId()).setBackgroundColor(0xFFFFC0CB);
                break;
            case "PU":
                findViewById(v.getId()).setBackgroundColor(0xFF800080);
                break;
            case "O":
                findViewById(v.getId()).setBackgroundColor(0xFFFFA500);
                break;
        }
        revealed[used]= String.valueOf(v.getId());
        used++;
    }
    //Funkcja przycisku restart
    public void restartGame(View v){
        Intent i = getIntent();
        finish();
        startActivity(i);
    }
    public void showGameList(View v){
        Intent i = new Intent(this, MainActivity.class);
        finish();
        startActivity(i);
    }
}