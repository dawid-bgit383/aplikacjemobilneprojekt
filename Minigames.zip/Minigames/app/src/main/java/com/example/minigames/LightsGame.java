package com.example.minigames;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.w3c.dom.Text;

import java.util.Collections;
import java.util.Random;

public class LightsGame extends AppCompatActivity {
    Light lights[][]={{new Light(R.id.field00),new Light(R.id.field01),new Light(R.id.field02),new Light(R.id.field03)},{new Light(R.id.field10),new Light(R.id.field11),new Light(R.id.field12),new Light(R.id.field13)},{new Light(R.id.field20),new Light(R.id.field21),new Light(R.id.field22),new Light(R.id.field23)},{new Light(R.id.field30),new Light(R.id.field31),new Light(R.id.field32),new Light(R.id.field33)}};
    Random rand= new Random();
    TextView stepscount;
    boolean victory=false;
    int totalsteps=0;
    //przy tworzeniu zmienia stan losowych przycisków na true
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        int r;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lights_game);
        r=rand.nextInt(6);
        ///////////////////przy losowym schemacie często trafiały się przykłady bez rozwiązań/////////
        /*for(int i=0;i<10;i++){
            r1=rand.nextInt(4);
            r2=rand.nextInt(4);
            if(!lights[r1][r2].getChosen()){
            findViewById(lights[r1][r2].getId()).setBackgroundColor(0xffffffff);
            lights[r1][r2].setState(true);
            lights[r1][r2].setChosen(true);
            }
            else{
                i--;
            }*/
        //////////////dlatego dodaję kilka sprawdzonych zbiorów/////////////////////
            switch(r){
                case 0:{
                    schema(0,1);
                    schema(0,2);
                    schema(1,2);
                    schema(1,3);
                    schema(2,3);
                    schema(3,0);
                    break;
                }
                case 1:{
                    schema(0,0);
                    schema(0,1);
                    schema(1,2);
                    schema(1,3);
                    schema(2,3);
                    schema(3,1);
                    break;
                }
                case 2:{
                    schema(0,1);
                    schema(1,0);
                    schema(3,1);
                    schema(3,2);
                    schema(3,3);
                    break;
                }
                case 3:{
                    schema(0,1);
                    schema(0,2);
                    schema(0,3);
                    schema(1,1);
                    schema(1,2);
                    schema(3,3);
                    break;
                }
                case 4:{
                    schema(2,0);
                    schema(2,2);
                    schema(3,3);
                    schema(3,1);
                    schema(0,3);
                    break;
                }
                case 5:{
                    schema(0,2);
                    schema(1,3);
                    schema(3,0);
                    schema(3,1);
                    schema(3,2);
                    break;
                }

            }

        }
    public void schema(int a,int b){
        findViewById(lights[a][b].getId()).setBackgroundColor(0xffffffff);
        lights[a][b].setState(true);
    }
    @Override
    protected void onDestroy(){
        super.onDestroy();
        Toast.makeText(this,"Zamykam obecną rozgrywkę",Toast.LENGTH_LONG).show();
    }
    //Funkcja przycisku restart
    public void restartGame(View v){
        Intent i = getIntent();
        finish();
        startActivity(i);
    }
    //przejście do MainActivity
    public void showGameList(View v){
        Intent i = new Intent(this, MainActivity.class);
        finish();
        startActivity(i);
    }
    //funkcja zmienia status guzika na przeciwny
    public void lightSwitch(int p1,int p2){
        if(checkForState(lights[p1][p2].getId())){
            findViewById(lights[p1][p2].getId()).setBackgroundColor(0x00000000);
            lights[p1][p2].setState(false);
        }
        else{
            findViewById(lights[p1][p2].getId()).setBackgroundColor(0xffffffff);
            lights[p1][p2].setState(true);
        }
    }
    //funkcja pobiera pozycje guzika w tablicy lights
    public boolean checkForState(int id){
        String temp=(String)findViewById(id).getTag();
        String pos[]=temp.split(":",0);
        return lights[Integer.parseInt(pos[0])][Integer.parseInt(pos[1])].getState();
    }
   //funkcja przełącza stany przycisków i sprawdza warunek zwycięstwa
    public void checkNeighbours(View v){
        if(!victory) {
            String temp = (String) findViewById(v.getId()).getTag();
            String pos[] = temp.split(":", 0);
            int p1 = Integer.parseInt(pos[0]);
            int p2 = Integer.parseInt(pos[1]);
            lightSwitch(p1, p2);
            changeState(p1, p2 - 1);
            changeState(p1, p2 + 1);
            changeState(p1 - 1, p2);
            changeState(p1 + 1, p2);
            totalsteps++;
            stepscount=(TextView)findViewById(R.id.nsteps);
            stepscount.setText(String.valueOf(totalsteps));
            if(checkVictoryCondition()){
                victory=true;
                Toast.makeText(this,"Jej udało ci się zgasić wszystkie guziki! Twój wynik to:"+totalsteps+" kroków. Naciśnij RESTART, aby zagrać jeszcze raz",Toast.LENGTH_LONG).show();
            }
        }
        else{
            Toast.makeText(this,"Jej udało ci się zgasić wszystkie guziki! Twój wynik to:"+totalsteps+" kroków. Naciśnij RESTART, aby zagrać jeszcze raz",Toast.LENGTH_LONG).show();
        }
    }
    //funkcja sprawdza czy wskazana pozycja jest prawidłowa
    public void changeState(int p1,int p2){
        try{
            lightSwitch(p1,p2);
        }
        catch(Exception e){

        }
    }
    public boolean checkVictoryCondition(){
        boolean victory=true;
        for(int i=0;i<4;i++){
            for(int j=0;j<4;j++){
                if(lights[i][j].getState()){
                    victory=false;
                }
            }
        }
        return victory;
    }
}
class Light{
   private int id;
   private boolean state=false;
   //private boolean chosen=false;
    public Light(int id){
        this.id=id;
    }
    public Light(){

    }
    public int getId() {
        return id;
    }
    public boolean getState(){
        return state;
    }
    public void setId(int id) {
        this.id = id;
    }
    public void setState(boolean state) {
        this.state = state;
    }
    /*public boolean getChosen(){
        return this.chosen;
    }
    public void setChosen(boolean){
        this.chosen=chosen;
    }*/
}


