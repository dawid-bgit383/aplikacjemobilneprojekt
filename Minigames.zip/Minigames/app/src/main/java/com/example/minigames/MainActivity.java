package com.example.minigames;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    @Override
    protected void onDestroy(){
        super.onDestroy();
        Toast.makeText(this,"Przechodzę do nowej aktywności",Toast.LENGTH_LONG).show();
    }
    public void startGame(View v){
        Intent i;
        switch(v.getId()){
            case R.id.memo:
                i = new Intent(this,MemoryGame.class);
                break;
            case R.id.memoone:
                i = new Intent(this,MemoryGameOne.class);
                break;
            case R.id.lights:
                i= new Intent(this,LightsGame.class);
                break;
            default:
                i = getIntent();
                break;
        }
        finish();
        startActivity(i);
    }
}
